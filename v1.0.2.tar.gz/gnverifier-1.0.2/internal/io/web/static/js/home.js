$(document).ready(function(){
  $("#advanced_options").on("click", function(e) {
    e.preventDefault();
    $("#advanced_selections").toggle();
  });
});
