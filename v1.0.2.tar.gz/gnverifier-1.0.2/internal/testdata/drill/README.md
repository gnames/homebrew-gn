# drill benchmarks

Use [drill](https://github.com/fcsonline/drill) project to run load testing.
