package gnverifier

var (
	// Version of the gnverifier
	Version = "v1.0.2"
	// Build timestamp
	Build string
)
